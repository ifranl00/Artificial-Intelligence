%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Crear una funcion que adem�s de asignar el valor num�rico a cada palabra
% de una frase devolver� un cell en el que se �ndica cada palabra y el 
% n�mero de veces que se repite.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function c = Ejercicio2(phrase)

c0 = regexp(phrase, ' ', 'split');
c1 = unique(c0);
c= cell(2,length(c1)); 

for i=1:length(c0)
    contador = 0;
    for j=1:length(c1)
        if(strcmp(c0{i},c1{j}) == 1)
                contador = contador +1;
                c{1,j}= c1{j};
                c{2,j}= contador;
        end
 
    end

end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejemplo de soluci�n
% I = 
% 
%     'Prueba'    'de'    'ejemplo'    'ejercicio2'
%     [     1]    [ 2]    [      1]    [         1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%