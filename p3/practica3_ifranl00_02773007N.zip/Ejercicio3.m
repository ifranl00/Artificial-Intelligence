%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creaci�n de una funci�n que nos va a dar los tiempos de procesado en
% funci�n de como reservemos la memoria y trabajemos con los datos.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Tiempos = Ejercicio3(n)
    
    % Inicializaci�n del array en el que vamos a guardar los tiempos
    Tiempos = zeros(1,3);
    numeros = 1:n;

    % Utilizando un bucle for sin declarar las variables. 
    t0 = cputime();
    for i=1:n
        cuadrados(i) = i^2;
    end
    t1 = cputime() -t0;
    
    
    % Utilizando un bucle for declarando previamente la variable. 
    t0 = cputime();
    cuadrados = zeros(1,3);
    for i=1:numeros
        cuadrados(i) = i^2;
    end
    t2 = cputime()-t;
    
    % Calculando el cuadrado del vector correspondiente
     t0 = cputime();
    cuadrados = (numeros).^2;
    t3 = cputime()-t;
    Tiempos = {t0,t1,t2}
end