%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Crear un script para trabajar con struct y cell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1.- Creaci�n de los struct de partida.

% Struct en el que se va a almacenar el primer trabajador
Estructura1 = struct('Nombre', 'Bernard','Tiempos', [25.8, 34.6, 22.9, 33.3], 'Calidad', [true, true,
false, true]);

% Struct ene el que se va a almacenar el segundo trabajador
Estructura2 = struct ('Nombre', 'Joe','Tiempos',[18.7, 19.9, 23.4, 18.0, 18.7, 20.0] , 'Calidad',[false,
true, true, false, true, false]);


% Calculo de los tiempos medios en la fabricaci�n de una pieza correcta para cada trabajador
function avg = Ejercicio4(Estructura)
contador0 = 0;
contador1 = 0;
sum0 = 0;
sum1 = 0;

if(Estructura == Estructura1)
    for i=1:size(Estructura1.tiempos)
        if(Estructura1.calidad(i) == 1)
            sum1 = sum1 + Estructura1.tiempos(i);
            contador0 = contador0 + 1;
        end   
    end
    Estructura1.Tmean = sum0/contador0
end
if(Estructura == Estructura2) 
    for j=1:size(Estructura2.tiempos)
        if(Estructura2.calidad(j) == 1)
            suma2 = suma2 + Estructura2.tiempos(j);
            counter2 = counter2 + 1;
        end
    end
    Estructura2.Tmean = sum1/contador1
end

end
% Conversion de las estructuras a cell y almacenamiento en la misma
% variable
Celda = [struct2cell(Estructura1)';struct2cell(Estructura2)'];

% Calculo de los tiempos medios en la fabricaci�n de una pieza incorrecta
% para cada trabajador
